/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.10-MariaDB, for Linux (x86_64)
--
-- Host: db    Database: ovo2
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notas`
--

DROP TABLE IF EXISTS `notas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notas` (
  `id_nota` int NOT NULL AUTO_INCREMENT,
  `tarea` int NOT NULL,
  `nota` text,
  `adjunto` varchar(500) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `autor` varchar(255) DEFAULT NULL,
  `fecha_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_nota`),
  KEY `tarea` (`tarea`),
  CONSTRAINT `notas_ibfk_1` FOREIGN KEY (`tarea`) REFERENCES `tareas` (`id_tarea`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas`
--

LOCK TABLES `notas` WRITE;
/*!40000 ALTER TABLE `notas` DISABLE KEYS */;
/*!40000 ALTER TABLE `notas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos`
--

DROP TABLE IF EXISTS `proyectos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos` (
  `id_proyecto` int NOT NULL AUTO_INCREMENT,
  `proyecto` varchar(50) NOT NULL,
  `nombre_proyecto` varchar(255) NOT NULL,
  `descripcion` text,
  `color` varchar(20) DEFAULT '#6366f1',
  PRIMARY KEY (`id_proyecto`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos`
--

LOCK TABLES `proyectos` WRITE;
/*!40000 ALTER TABLE `proyectos` DISABLE KEYS */;
INSERT INTO `proyectos` VALUES
(1,'P0001','Galpon 12',NULL,'Red'),
(2,'P0002','Ampliación servicios G12',NULL,'Blue'),
(3,'P0003','TGBT Postura 1',NULL,'Green'),
(4,'P0004','Grupos PPH','Planta procesadora de huevos','Black'),
(5,'P0005','Ampliación servicios PPH',NULL,'Orange'),
(6,'P0006','Ampliación PPH',NULL,'Purple'),
(7,'P0007','Efluentes',NULL,'Yellow');
/*!40000 ALTER TABLE `proyectos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recursos`
--

DROP TABLE IF EXISTS `recursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recursos` (
  `id_recurso` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `area` varchar(100) DEFAULT NULL,
  `rol` varchar(100) DEFAULT NULL,
  `valor_hora` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id_recurso`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recursos`
--

LOCK TABLES `recursos` WRITE;
/*!40000 ALTER TABLE `recursos` DISABLE KEYS */;
INSERT INTO `recursos` VALUES
(1,'Juan','Mantenimiento','Electricista',20000.00),
(2,'Pedro','Mantenimiento','Mecánico',20000.00),
(3,'Lucas','Proyectos','LP',25000.00),
(4,'Mariano','Proyectos','LP',25000.00),
(5,'Germán','Gerencia','Gerente',50000.00);
/*!40000 ALTER TABLE `recursos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `responsables`
--

DROP TABLE IF EXISTS `responsables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `responsables` (
  `id_resp` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `rol` varchar(100) DEFAULT NULL,
  `equipo` varchar(100) DEFAULT NULL,
  `foto` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id_resp`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `responsables`
--

LOCK TABLES `responsables` WRITE;
/*!40000 ALTER TABLE `responsables` DISABLE KEYS */;
INSERT INTO `responsables` VALUES
(1,'FAdamoli','FAdamoli@ovobrand.com.ar','Technician','Civil',NULL),
(2,'JPLinari','JPLinari@ovobrand.com.ar','Manager','Compras',NULL),
(3,'GMorano','GMorano@ovobrand.com.ar','Technician','Mantenimiento',NULL),
(4,'FCaputo','FCaputo@ovobrand.com.ar',NULL,'Industrial',NULL);
/*!40000 ALTER TABLE `responsables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subresponsables`
--

DROP TABLE IF EXISTS `subresponsables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subresponsables` (
  `id_subresp` int NOT NULL AUTO_INCREMENT,
  `id_lead` int NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  PRIMARY KEY (`id_subresp`),
  UNIQUE KEY `correo` (`correo`),
  KEY `id_lead` (`id_lead`),
  CONSTRAINT `subresponsables_ibfk_1` FOREIGN KEY (`id_lead`) REFERENCES `responsables` (`id_resp`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subresponsables`
--

LOCK TABLES `subresponsables` WRITE;
/*!40000 ALTER TABLE `subresponsables` DISABLE KEYS */;
INSERT INTO `subresponsables` VALUES
(1,3,'Mariano','mariano@ovobrand.com');
/*!40000 ALTER TABLE `subresponsables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tareas`
--

DROP TABLE IF EXISTS `tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tareas` (
  `id_tarea` int NOT NULL AUTO_INCREMENT,
  `id_proyecto` int NOT NULL,
  `id_parent` int DEFAULT NULL,
  `id_subresp` int DEFAULT NULL,
  `tarea` varchar(100) DEFAULT NULL,
  `descripcion` text,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_inicio_proyectada` date DEFAULT NULL,
  `duracion_dias` int DEFAULT '1',
  `fecha_fin` date DEFAULT NULL,
  `fecha_completada` date DEFAULT NULL,
  `estado` varchar(50) DEFAULT 'No comenzada',
  `responsable` varchar(255) DEFAULT NULL,
  `avance` decimal(5,2) DEFAULT '0.00',
  `dependencias` text,
  `costo_tarea` decimal(10,2) DEFAULT '0.00',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `notificado` tinyint(1) DEFAULT '0',
  `recursos` text,
  `fecha_iniciada` datetime DEFAULT NULL,
  `fecha_finalizada` datetime DEFAULT NULL,
  `tipo_dias` enum('calendario','laboral') DEFAULT 'calendario',
  PRIMARY KEY (`id_tarea`),
  KEY `id_proyecto` (`id_proyecto`),
  KEY `id_parent` (`id_parent`),
  KEY `id_subresp` (`id_subresp`),
  CONSTRAINT `tareas_ibfk_1` FOREIGN KEY (`id_proyecto`) REFERENCES `proyectos` (`id_proyecto`) ON DELETE CASCADE,
  CONSTRAINT `tareas_ibfk_2` FOREIGN KEY (`id_parent`) REFERENCES `tareas` (`id_tarea`) ON DELETE CASCADE,
  CONSTRAINT `tareas_ibfk_3` FOREIGN KEY (`id_subresp`) REFERENCES `subresponsables` (`id_subresp`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tareas`
--

LOCK TABLES `tareas` WRITE;
/*!40000 ALTER TABLE `tareas` DISABLE KEYS */;
INSERT INTO `tareas` VALUES
(1,1,NULL,NULL,'T0001','Obra civil G12','2026-03-01',NULL,116,'2026-06-24',NULL,'En progreso','GMorano@ovobrand.com.ar',5.00,NULL,3500000.00,'2026-03-26 00:00:00',0,'4,2',NULL,NULL,'calendario'),
(2,1,NULL,NULL,'T0002','Compra de materiales / cables','2026-07-15','2026-07-15',15,'2026-07-30',NULL,'No comenzada','JPLinari@ovobrand.com.ar',0.00,NULL,2500000.00,'2026-03-26 00:00:00',0,'2',NULL,NULL,'calendario'),
(3,1,NULL,NULL,'T0003','Instalación electrica','2026-08-10','2026-08-10',100,'2026-11-18',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'2',4500000.00,'2026-03-26 00:00:00',0,NULL,NULL,NULL,'calendario'),
(4,2,NULL,NULL,'T0004','Ampliación sala de grupos POSTURA 2','2026-03-01',NULL,61,'2026-04-30',NULL,'En progreso','FAdamoli@ovobrand.com.ar',3.00,NULL,0.00,'2026-03-26 00:00:00',0,NULL,NULL,NULL,'calendario'),
(5,2,NULL,NULL,'T0005','Armado de la tgbt','2026-04-01',NULL,91,'2026-06-30',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,NULL,0.00,'2026-03-29 00:00:00',0,NULL,NULL,NULL,'calendario'),
(6,2,NULL,NULL,'T0006','Montaje de la TGBT (Tablero general de baja tensión)','2026-07-01','2026-07-01',3,'2026-07-02',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'5',2500000.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(7,2,NULL,NULL,'T0007','Recableado TGBT','2026-07-04','2026-07-03',10,'2026-07-11',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'6',0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(8,2,NULL,NULL,'T0008','Compra de los grupos','2026-04-01','2026-04-01',10,'2026-04-11',NULL,'No comenzada','JPLinari@ovobrand.com.ar',0.00,NULL,3500000.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(9,2,NULL,NULL,'T0009','Fabricación de grupos','2026-04-11','2026-04-11',140,'2026-08-29',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'8',0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(10,2,NULL,NULL,'T0010','Montaje de grupos / coneccionado','2026-09-01','2026-09-01',10,'2026-09-11',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'9',0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(11,2,NULL,NULL,'T0011','Tendido de potencia y bandejas al G12','2026-07-05','2026-07-03',20,'2026-07-21',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'6',0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(12,3,NULL,NULL,'T0012','Ampliación sala de grupos POSTURA 1','2026-04-01','2026-04-01',15,'2026-04-16',NULL,'No comenzada','FAdamoli@ovobrand.com.ar',0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(13,3,NULL,NULL,'T0013','Compra de los grupos','2026-04-01','2026-04-01',10,'2026-04-11',NULL,'No comenzada','JPLinari@ovobrand.com.ar',0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(14,3,NULL,NULL,'T0014','Fabricación de grupos','2026-04-01','2026-04-01',90,'2026-06-30',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(15,3,NULL,NULL,'T0015','Instalación de nuevos grupos','2026-04-01','2026-04-01',10,'2026-04-11',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(16,4,NULL,NULL,'T0016','Ampliación sala de grupos PPH','2026-04-01','2026-04-01',20,'2026-04-21',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(17,4,NULL,NULL,'T0017','Compra de los grupos','2026-04-01','2026-04-01',10,'2026-04-11',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(18,4,NULL,NULL,'T0018','Fabricación de grupos','2026-04-01','2026-04-01',90,'2026-06-30',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(19,4,NULL,NULL,'T0019','Instalación de nuevos grupos','2026-04-01','2026-04-01',10,'2026-04-11',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(20,5,NULL,NULL,'T0020','Caldera','2026-04-01','2026-04-01',1,'2026-04-01',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(21,5,NULL,NULL,'T0021','Armado de equipos frio','2026-04-01','2026-04-01',150,'2026-08-29',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(22,5,NULL,NULL,'T0022','Frío (VMC)','2026-04-01','2026-04-01',90,'2026-06-30',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(23,6,NULL,NULL,'T0023','Equipos sanovo','2026-04-01','2026-04-01',170,'2026-09-18',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(24,6,NULL,NULL,'T0024','Tendido electrico','2026-04-13',NULL,28,'2026-05-10',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(25,6,NULL,NULL,'T0025','Tanques / Nueva sala','2026-04-01','2026-04-01',140,'2026-08-19',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(26,6,NULL,NULL,'T0026','Tendido electrico','2026-04-01','2026-04-01',10,'2026-04-11',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(27,6,NULL,NULL,'T0027','Instalción electrica','2026-04-01','2026-04-01',40,'2026-05-11',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(28,1,NULL,NULL,'T0028','Montaje mecánica (jaulas, niagras, alimento, recojida de guano)','2026-06-20','2026-06-01',130,'2026-10-28',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(29,1,NULL,NULL,'T0029','Fabricación de recogida de guano','2026-05-01','2026-05-01',130,'2026-09-08',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(30,1,NULL,NULL,'T0030','Montaje recogida de guano','2026-09-10','2026-09-10',20,'2026-09-30',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(31,1,NULL,NULL,'T0031','Fabricación cadena de transporte de huevos','2026-05-01','2026-05-01',120,'2026-08-29',NULL,'No comenzada',NULL,0.00,NULL,0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(32,1,NULL,NULL,'T0032','Montaje cadena de transporte de huevos','2026-09-01','2026-09-01',60,'2026-10-31',NULL,'No comenzada',NULL,0.00,'31',0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(33,2,NULL,NULL,'T0037','Cableado de los grupos (montaje bandejas, conexionado a TGBT)','2026-07-05','2026-07-03',10,'2026-07-11',NULL,'No comenzada','GMorano@ovobrand.com.ar',0.00,'6',0.00,'2026-04-02 19:51:07',0,NULL,NULL,NULL,'calendario'),
(36,1,1,1,'Prueba','Obra civil','2026-03-01',NULL,116,'2026-06-24',NULL,'En progreso','GMorano@ovobrand.com.ar',10.00,NULL,0.00,'2026-04-02 21:46:13',0,NULL,NULL,NULL,'calendario');
/*!40000 ALTER TABLE `tareas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `permisos` varchar(255) DEFAULT 'READ',
  `proyectos` text,
  `es_admin` tinyint(1) DEFAULT '0',
  `activo` tinyint(1) DEFAULT '1',
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES
(1,'admin@ovo2.com','$2b$10$OW9VCxm2P28LbIV8iE8npOk5kYyXoc/SkAK.kRoHbys4ZSXxUGuAW','Administrador','ALL','ALL',1,1,'2026-04-04 18:43:53'),
(3,'GMorano@ovobrand.com.ar','$2b$10$niet03sbVulknGemlyN1f.EKAGAPwXhfsldbx2Mok5u1Uyj0pAiGy','GermanMorano','ALL','ALL',0,1,'2026-04-04 18:43:53');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-05  3:00:00
